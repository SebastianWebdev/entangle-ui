# Full Editor

> A complete 3D editor interface built entirely with Entangle UI components.

A complete 3D editor interface assembled from Entangle UI components — menu bar, toolbars, split panes, scene tree, 3D viewport with wireframe cube and orientation gizmo, console panel, property inspector with 8+ sections, floating panel, AI chat, and status bar. Every control is fully interactive.

<a
href="/showcase/editor/"
style="display:inline-flex;align-items:center;gap:0.5rem;padding:0.6rem 1.2rem;background:#007acc;color:#fff;border-radius:6px;text-decoration:none;font-weight:500;font-size:0.95rem;margin-top:0.5rem;"

> Open Full Editor ↗
> </a>
